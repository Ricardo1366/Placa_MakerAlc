# Arduino AVR Boards

[![Check Arduino status](https://github.com/arduino/ArduinoCore-avr/actions/workflows/check-arduino.yml/badge.svg)](https://github.com/arduino/ArduinoCore-avr/actions/workflows/check-arduino.yml)
[![Compile Examples status](https://github.com/arduino/ArduinoCore-avr/actions/workflows/compile-platform-examples.yml/badge.svg)](https://github.com/arduino/ArduinoCore-avr/actions/workflows/compile-platform-examples.yml)
[![Spell Check status](https://github.com/arduino/ArduinoCore-avr/actions/workflows/spell-check.yml/badge.svg)](https://github.com/arduino/ArduinoCore-avr/actions/workflows/spell-check.yml)

This repository contains the source code and configuration files of the Arduino AVR Boards
[platform](https://arduino.github.io/arduino-cli/latest/platform-specification/).
